"""
Video -> Markdown MCP server (V1)

What it does
------------
An AI client (Claude, ChatGPT, Gemini) calls ONE tool, `process_video(url)`.
The server then:
  1. Downloads the video          (yt-dlp)
  2. Pulls out the audio          (ffmpeg)  -> transcribes it   (faster-whisper)
  3. Pulls out 1 frame / second   (ffmpeg)  -> reads the text   (EasyOCR)
  4. Drops repeated on-screen text            (thefuzz)
  5. Returns everything as a Markdown string

How it talks to the AI client
-----------------------------
Over the network using "Streamable HTTP" (the modern remote MCP transport).
The MCP endpoint is:   https://<your-server>/mcp
(NOT stdio - stdio only works for programs running on the same computer.)
"""

import asyncio
import glob
import os
import shutil
import subprocess
import tempfile
from contextlib import asynccontextmanager
from urllib.parse import parse_qs

import easyocr
import uvicorn
import yt_dlp
from faster_whisper import WhisperModel
from fastapi import FastAPI
from mcp.server.fastmcp import FastMCP
from starlette.responses import PlainTextResponse
from thefuzz import fuzz

# ---------------------------------------------------------------------------
# Settings (all can be changed with environment variables on Render)
# ---------------------------------------------------------------------------
WHISPER_MODEL = os.environ.get("WHISPER_MODEL", "base")  # tiny / base / small
MAX_VIDEO_SECONDS = int(os.environ.get("MAX_VIDEO_SECONDS", "300"))  # reject long videos
OCR_LANGUAGES = os.environ.get("OCR_LANGS", "en").split(",")  # e.g. "en,hi"
SIMILARITY_LIMIT = 85  # OCR text more than 85% similar to the previous frame is dropped
SECRET_KEY = os.environ.get("SECRET_KEY", "")  # optional password (see DEPLOYMENT.md)
COOKIES_FILE = os.environ.get("COOKIES_FILE", "")  # optional Instagram cookies.txt


# ---------------------------------------------------------------------------
# Load the AI models only once (the first time they are needed)
# ---------------------------------------------------------------------------
_whisper = None
_ocr = None


def get_whisper():
    global _whisper
    if _whisper is None:
        # int8 on CPU = small and fast enough, no GPU needed
        _whisper = WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8")
    return _whisper


def get_ocr():
    global _ocr
    if _ocr is None:
        _ocr = easyocr.Reader(OCR_LANGUAGES, gpu=False)
    return _ocr


# ---------------------------------------------------------------------------
# Small helper functions
# ---------------------------------------------------------------------------
def run(command):
    """Run a command-line program (like ffmpeg). Raise a clear error if it fails."""
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"{command[0]} failed: {result.stderr[-300:]}")


def mmss(seconds):
    """Turn 75 into '01:15'."""
    seconds = int(seconds)
    return f"{seconds // 60:02d}:{seconds % 60:02d}"


# ---------------------------------------------------------------------------
# Step 1: download the video
# ---------------------------------------------------------------------------
def download_video(url, folder):
    """Download the video into `folder`. Returns (file_path, title)."""
    options = {
        "outtmpl": f"{folder}/video.%(ext)s",  # save as video.mp4 (or similar)
        "format": "best[height<=720]/best",  # 720p is plenty for OCR + speech
        "merge_output_format": "mp4",
        "noplaylist": True,
        "quiet": True,
        # skip videos that are too long (they would take too long to process)
        "match_filter": yt_dlp.utils.match_filter_func(f"duration <= {MAX_VIDEO_SECONDS}"),
    }

    # Instagram often needs a logged-in session. If you gave us a cookies file,
    # use a COPY of it (the original is read-only on Render).
    if COOKIES_FILE and os.path.exists(COOKIES_FILE):
        cookies_copy = os.path.join(folder, "cookies.txt")
        shutil.copy(COOKIES_FILE, cookies_copy)
        options["cookiefile"] = cookies_copy

    with yt_dlp.YoutubeDL(options) as downloader:
        info = downloader.extract_info(url, download=True)

    files = glob.glob(f"{folder}/video.*")
    if not files:
        raise RuntimeError(
            f"Video was not downloaded. It may be private, blocked, or longer than "
            f"{MAX_VIDEO_SECONDS} seconds."
        )
    return files[0], (info or {}).get("title", "Untitled video")


# ---------------------------------------------------------------------------
# Step 2: audio -> transcript
# ---------------------------------------------------------------------------
def transcribe_audio(video_path, folder):
    """Returns a list of (start_seconds, text)."""
    audio_path = f"{folder}/audio.wav"
    # -vn = no video, mono, 16 kHz = the format Whisper likes
    run(["ffmpeg", "-y", "-i", video_path, "-vn", "-ac", "1", "-ar", "16000", audio_path])

    # vad_filter skips silent parts, so music-only videos don't produce nonsense
    segments, _info = get_whisper().transcribe(audio_path, vad_filter=True)
    return [(seg.start, seg.text.strip()) for seg in segments if seg.text.strip()]


# ---------------------------------------------------------------------------
# Step 3 + 4: frames -> OCR -> remove duplicates
# ---------------------------------------------------------------------------
def read_screen_text(video_path, folder):
    """Returns a list of (second, text) with repeated text removed."""
    frames_folder = f"{folder}/frames"
    os.makedirs(frames_folder)

    # fps=1 -> exactly one picture per second
    run(["ffmpeg", "-y", "-i", video_path, "-vf", "fps=1", f"{frames_folder}/f_%04d.jpg"])

    ocr = get_ocr()
    results = []
    previous_text = ""

    # Files are named f_0001.jpg, f_0002.jpg ... so sorting gives time order.
    for index, frame_path in enumerate(sorted(glob.glob(f"{frames_folder}/*.jpg"))):
        # detail=0 -> give back only the text pieces, no boxes or scores
        pieces = ocr.readtext(frame_path, detail=0)
        text = " ".join(pieces).strip()

        if not text:
            continue  # nothing on screen in this frame

        # How similar is this frame's text to the previous frame's text? (0-100)
        similarity = fuzz.ratio(text.lower(), previous_text.lower())
        previous_text = text

        if similarity > SIMILARITY_LIMIT:
            continue  # basically the same text as before -> skip it

        results.append((index, text))  # frame 0 = second 0, frame 1 = second 1, ...

    return results


# ---------------------------------------------------------------------------
# Step 5: put everything together as Markdown
# ---------------------------------------------------------------------------
def build_markdown(url, title, speech, screen_text):
    lines = [f"# {title}", f"Source: {url}", "", "## Spoken audio"]

    if speech:
        for start, text in speech:
            lines.append(f"- **[{mmss(start)}]** {text}")
    else:
        lines.append("_No speech detected._")

    lines += ["", "## On-screen text"]
    if screen_text:
        for second, text in screen_text:
            lines.append(f"- **[{mmss(second)}]** {text}")
    else:
        lines.append("_No on-screen text detected._")

    return "\n".join(lines)


def process(url):
    """The whole pipeline. Runs in a background thread (it is slow)."""
    # TemporaryDirectory deletes the video, audio and frames when we are done.
    with tempfile.TemporaryDirectory() as folder:
        video_path, title = download_video(url, folder)
        speech = transcribe_audio(video_path, folder)
        screen_text = read_screen_text(video_path, folder)
    return build_markdown(url, title, speech, screen_text)


# ---------------------------------------------------------------------------
# The MCP server and its single tool
# ---------------------------------------------------------------------------
# host="0.0.0.0" lets the server accept requests from the internet.
# stateless_http=True means "no sessions to remember" - simplest for hosting.
# json_response=True means plain JSON replies - works well behind proxies.
mcp = FastMCP(
    "video-to-markdown",
    host="0.0.0.0",
    stateless_http=True,
    json_response=True,
)

# Only process one video at a time, so a small server doesn't run out of memory.
one_at_a_time = asyncio.Lock()


@mcp.tool()
async def process_video(url: str) -> str:
    """Download a video (Instagram reel, YouTube, TikTok, etc.) from a URL and
    return a Markdown transcript with the spoken words and the on-screen text,
    each with a [mm:ss] timestamp. Takes roughly 1-3 minutes per video."""
    try:
        async with one_at_a_time:
            # to_thread keeps the server responsive while the slow work runs
            return await asyncio.to_thread(process, url)
    except Exception as error:
        # Return the error as text so the AI can explain it to the user
        return f"Could not process the video: {error}"


# ---------------------------------------------------------------------------
# The web app (FastAPI) that wraps the MCP server
# ---------------------------------------------------------------------------
mcp_app = mcp.streamable_http_app()  # the MCP endpoint lives at /mcp


@asynccontextmanager
async def lifespan(app):
    # The MCP session manager must be started/stopped together with the app.
    async with mcp.session_manager.run():
        yield


app = FastAPI(lifespan=lifespan)


@app.get("/health")
def health():
    """Render pings this to check that the server is alive."""
    return {"status": "ok"}


# Everything that is not /health is handled by the MCP app (so /mcp works).
app.mount("/", mcp_app)


class SecretKeyCheck:
    """Optional password. If SECRET_KEY is set, requests must end with ?key=<SECRET_KEY>."""

    def __init__(self, inner_app):
        self.inner_app = inner_app

    async def __call__(self, scope, receive, send):
        if SECRET_KEY and scope["type"] == "http" and scope["path"] != "/health":
            query = parse_qs(scope["query_string"].decode())
            if query.get("key", [""])[0] != SECRET_KEY:
                denied = PlainTextResponse("Unauthorized", status_code=401)
                await denied(scope, receive, send)
                return
        await self.inner_app(scope, receive, send)


app.add_middleware(SecretKeyCheck)


if __name__ == "__main__":
    # Render tells us which port to use through the PORT environment variable.
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
